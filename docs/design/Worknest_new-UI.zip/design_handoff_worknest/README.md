# Handoff: Worknest — Ticket Management App

## Overview

Worknest is a ticket management application for project teams. After login, users see a dashboard of their projects; selecting a project opens a tickets view with rich filtering and a list ↔ kanban toggle. Tickets open as a side sheet with full detail and a comment composer. New projects and tickets are created through modal flows.

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes showing the intended look and behavior, not production code to copy directly. The task is to **recreate these designs in the target codebase's existing environment** (React, Vue, SwiftUI, native, etc.) using its established patterns and libraries. If no environment exists yet, choose the most appropriate framework for the project and implement the designs there.

The prototype is built with React + Babel-in-browser inside a single HTML file. Component decomposition there is a starting point for thinking about the real implementation, not a prescription.

## Fidelity

**High-fidelity.** Final colors, typography, spacing, radii, and interaction details are settled. Recreate pixel-perfectly using the codebase's existing UI primitives and design tokens. If the codebase has its own component library (buttons, inputs, modals, etc.), prefer those over rebuilding — but match the visual treatments documented below.

## Direction

- Friendly & modern (Asana / Linear lineage)
- Indigo primary accent
- Warm-neutral backgrounds (paper-like, not stark white)
- Generous whitespace, spacious density
- Soft project cover colors as a categorical palette
- Rounded corners throughout (10–20px radii)
- Light + dark are first-class — both must work

---

## Screens

### 1. Login

**Purpose:** Authenticate into a workspace.

**Layout:** Two-column split.
- **Left (flex 1):** Marketing/hero panel. Indigo gradient background with two soft blurred blobs (pink top-right, mint bottom-left). Top: Worknest logo + wordmark. Middle: tagline H2 ("Where work finds its rhythm.") + supporting paragraph. Bottom-right: stack of three preview ticket cards rotated -3°, each showing a fake ticket ID, title, and status pill — gives a glimpse of the product.
- **Right (480px fixed):** Form panel. Theme toggle top-right. "Welcome back" h1, sub-copy, email + password fields, primary "Sign in" button (full width), divider, two SSO buttons (Google + GitHub) side by side, "Create an account" alt link.

**Interactions:**
- Email/password submit → simulated 700ms delay → navigate to dashboard.
- SSO buttons → straight to dashboard (mock).
- Theme toggle swaps the form panel between light/dark; the gradient hero stays constant.

---

### 2. Projects Dashboard

**Purpose:** Post-login home. Pick a project or create a new one.

**Layout:**
- **Sidebar (240px fixed):** Logo, primary nav (Dashboard, Inbox with badge, My tickets), "Projects" section with up to 5 starred projects each prefixed by a colored dot, "+ New project" entry. Bottom: theme toggle, Settings, current user pill.
- **Topbar (full width of main):** Breadcrumb (Workspace / Dashboard), notifications bell, theme toggle, user avatar.
- **Content (28px / 32px / 60px padding):**
  - Page head: "Good afternoon, Alex" h1 (with gradient-text accent on the name), date + summary sub-copy, "+ New project" primary button on the right.
  - Stat row: 4-col grid of stat cards (Open tickets, Assigned to me, Due this week, Active projects). Each card has a small label, a 24px bold value, and an optional delta line (green for positive, red for negative).
  - Section header: "Your projects" (18px) on the left, project count on the right.
  - Project grid: `repeat(auto-fill, minmax(280px, 1fr))`, 16px gap. Each project card has a 56px colored banner with an icon, then body padding with name, 2-line description (clamped), footer row showing open count + progress %, member avatar stack, then a 4px progress bar. Final card is a dashed "+ New project" tile.

**Interactions:**
- Click project card → navigate to project detail.
- Click "+ New project" (button or tile) → open create-project modal.
- Hover project card: lifts 2px, deeper shadow, border darkens.

---

### 3. Project Detail

**Purpose:** Browse and triage tickets in a project.

**Layout:**
- Same sidebar + topbar as dashboard. Topbar breadcrumb extends to: Workspace / Projects / [Project name].
- Back link "← Projects" above page head.
- Page head: 48×48 colored project icon tile + title + description on the left; member avatar stack, "Invite" secondary button, "+ New ticket" primary button on the right.
- **Filter bar** (flex-wrap, 10px gap):
  - Search input (280px) with magnifier icon.
  - Filter chips: Status, Priority, Assignee, Label, Date — each a popover with single-select options. Active chips show their value inline (e.g. "Status: Open") with an X to clear, and use indigo-fill styling.
  - "My tickets" toggle chip (uses indigo-tint variant when active, not full fill).
  - "Clear" ghost button when any filter is active.
  - Right side: "{n} of {total}" count + view toggle (List / Board).
- **List view:** Table with columns ID (70px) / Title (1fr, with inline tag chips) / Status (110) / Priority (110) / Assignee (110) / Due (90) / Activity (80). Header row in surface-2 with uppercase 11px labels. Body rows 14px padding, hover surface-2 background, cursor pointer.
- **Board view:** 4-column grid (Open / In Progress / Done / Blocked), each column is a surface-2 panel with a header row (colored dot + name + count pill + + button) and stacked ticket cards. Each card shows ID, title, tag chips, then a meta row with priority and assignee + comment count. "+ Add ticket" ghost row at the bottom.

**Interactions:**
- Search filters by title or ID, case-insensitive, live.
- Filter chips: click to open popover, select value to apply, click X or re-select to clear. Filters AND together.
- "My tickets" toggle filters by assignee=me.
- View toggle persists locally (component state).
- Click any ticket row/card → open ticket sheet.
- "+ New ticket" → open create-ticket modal.

---

### 4. Ticket Detail (side sheet)

**Purpose:** Read and update a single ticket.

**Layout:**
- Side sheet, 720px wide, slides in from the right with a scrim over the project view.
- **Sheet head:** ID pill (monospace), status pill, "updated 2h ago" muted text, more / close buttons on the right.
- **Sheet body** (grid: 1fr / 240px):
  - **Main column** (24/28 padding): Title h1 (22px), description paragraph + acceptance-criteria bullet list, attachment chips, "Activity · N comments" section, comment list, comment composer at bottom.
  - **Side rail** (border-left, surface-2 bg, 24/20 padding): Property rows — Status (editable select), Priority (badge), Assignee (avatar+name), Reporter, Due, Labels, Project. Divider, then Watchers avatar stack.

**Comment row:** sm avatar + bubble. Bubble has author name + timestamp meta row, then body text. Surface-2 background, 10px radius.

**Composer:** sm avatar + input wrapper. Input wrapper is a bordered rounded box containing a textarea (no internal border) and a row of action icons (paperclip, image) on the left + primary "Comment" button on the right (disabled until content).

**Interactions:**
- Status select changes the status pill in real time.
- Close button or scrim click dismisses the sheet.
- Animation: `slideRight 0.22s cubic-bezier(.2,.7,.3,1)`.

---

### 5. Create Project Modal

**Purpose:** Make a new project in 2 steps.

**Layout:**
- 600px modal, scrim backdrop. Head with title + close. Foot with Cancel + primary action.
- **Step 1 — Details:**
  - Name (input) + Key (input, monospace, 5-char cap, auto-derived from name initials).
  - Description (textarea).
  - Cover color: 6 swatches, 32px squares, 8px radius.
  - Icon: 8-col grid of 16 emoji options.
  - Live preview: a real project card below the form, updating as the user types/picks.
  - Foot: "Continue →" primary, disabled until name has content.
- **Step 2 — Members:**
  - Subhead "Invite teammates to collaborate."
  - Checkbox list of available people; selected rows get an indigo-tint background.
  - Foot: Back (secondary) + "✓ Create project" (primary).

**Interactions:**
- Name → key auto-derivation runs only when key is empty.
- On create: close modal, show toast "Project '[name]' created" for ~2.4s.

---

### 6. Create Ticket Modal

**Purpose:** Make a new ticket inline.

**Layout:**
- 620px modal. Head: "New ticket" h2 + "in [Project name]" subtitle.
- Body: large title input (16px font, prominent), description textarea, 3-col row (Status / Priority / Assignee selects), Due date with calendar icon (200px max), Labels — toggleable colored chips, dimmed when off, ringed in own color when on.
- Foot: Cancel + "✓ Create ticket" (primary, disabled until title has content).

**Interactions:**
- Submit → close, toast "Ticket '[title]' created".

---

## Design Tokens

### Color — Light theme
| Token | Hex |
|---|---|
| `--bg` | `#f7f6f3` |
| `--surface` | `#ffffff` |
| `--surface-2` | `#faf9f6` |
| `--surface-3` | `#f1efeb` |
| `--border` | `#e7e3dc` |
| `--border-strong` | `#d8d3ca` |
| `--text` | `#1c1b1a` |
| `--text-2` | `#54514c` |
| `--text-3` | `#8a857d` |

### Color — Dark theme
| Token | Hex |
|---|---|
| `--bg` | `#14141a` |
| `--surface` | `#1c1c24` |
| `--surface-2` | `#232330` |
| `--surface-3` | `#2a2a38` |
| `--border` | `#2e2e3c` |
| `--border-strong` | `#3a3a4d` |
| `--text` | `#f1efeb` |
| `--text-2` | `#b4b1a9` |
| `--text-3` | `#7d7a72` |

### Accent (indigo)
| Step | Hex |
|---|---|
| 50  | `#eef0ff` |
| 100 | `#dde1ff` |
| 200 | `#c1c7ff` |
| 300 | `#9aa3ff` |
| 400 | `#7a82f0` |
| 500 | `#5b5fc7` ← primary |
| 600 | `#4a4eb0` |
| 700 | `#3c3f95` |
| 800 | `#2f3175` |

In dark mode the primary shifts up to `#7a82f0` (the 400 step) for adequate contrast on dark surfaces.

### Status colors
- Open: `#6b7280` (slate)
- In Progress: `#f59e0b` (amber)
- Done: `#10b981` (emerald)
- Blocked: `#ef4444` (red)

### Priority colors
- Low: `#94a3b8`
- Medium: `#3b82f6`
- High: `#f59e0b`
- Urgent: `#ef4444` (text also recolors to this)

### Project cover palette (categorical, soft)
- Amber `#fde68a` · Violet `#c4b5fd` · Mint `#a7f3d0` · Pink `#fbcfe8` · Sky `#bae6fd` · Peach `#fed7aa`

### Tag/label palette
Pastel pairs (bg / fg):
- bug: `#fee2e2` / `#991b1b`
- feature: `#dbeafe` / `#1e40af`
- design: `#fce7f3` / `#9d174d`
- research: `#e0e7ff` / `#3730a3`
- docs: `#d1fae5` / `#065f46`
- chore: `#f1f5f9` / `#475569`

(See `styles.css` for the dark-mode counterparts — same hue, deeper bg, lighter fg.)

### Typography
- Family: **Geist**, falling back to Inter, system-ui sans
- Body: 14px / 1.5
- Small / meta: 12–12.5px
- Section header: 18px / 600 / -0.01em
- Page title (h1): 26px / 700 / -0.02em
- Login title: 28px / 700 / -0.02em
- Hero quote: 36px / 700 / -0.02em / 1.15
- Stat values: 24px / 700 / -0.02em
- Uppercase eyebrow ("ACTIVITY", "ATTACHMENTS"): 11px / 600 / 0.06em letter-spacing

### Radii
- `--radius-sm` 6px (tags, small chips)
- `--radius` 10px (inputs, board cards, attachments)
- `--radius-lg` 14px (project cards, ticket list panel, board columns)
- `--radius-xl` 20px (modals)
- 999px for pills / round buttons

### Shadows
- `--shadow-sm`: `0 1px 2px rgba(28,27,26,0.04), 0 1px 3px rgba(28,27,26,0.04)`
- `--shadow-md`: `0 4px 12px rgba(28,27,26,0.06), 0 2px 4px rgba(28,27,26,0.04)`
- `--shadow-lg`: `0 16px 40px rgba(28,27,26,0.10), 0 4px 12px rgba(28,27,26,0.05)`
- Dark mode equivalents use rgba(0,0,0, …) at 0.3 / 0.35 / 0.45.

### Spacing
Free-form rather than a strict scale. Common values: 4, 6, 8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 48px. Page content padding: 28px top / 32px sides / 60px bottom. Card padding: 16–20px. Modal head/body/foot: 20/14/24.

### Motion
- Hover transitions: 0.12s
- Card lift: 0.15s
- Modal/sheet entry: 0.2–0.22s
- Sheet easing: `cubic-bezier(.2, .7, .3, 1)`

---

## Components

### Button
- Variants: `primary` (indigo bg, white text, inset bottom shadow + soft drop shadow), `secondary` (surface bg, strong border), `ghost` (transparent, surface-3 hover), `icon` (square, 7px padding).
- Padding 8/14, radius 8, weight 500, font-size 13.5.
- Icons render at 14×14 to the left of label, 6px gap.

### Input / Select / Textarea
- Border `--border-strong`, radius 8, padding 9/12, 13.5px font.
- Focus: border becomes `--accent-500` + 3px `--accent-100` glow ring (dark mode uses indigo at 0.25 alpha).
- Search input: prefix magnifier icon at 10px from left, input has 32px left-padding.

### Pills (status)
- Inline-flex, 3/9 padding, 999px radius, 12px font, 500 weight, 6×6 dot before label.
- Color set per status (see above).

### Priority badge
- Bar-graph glyph (3 vertical bars at 3/6/9px height) + text.
- Bars colored by priority; inactive bars are 30% opacity neutral.

### Tags
- Inline-flex, 2/8 padding, 6px radius, 11.5px / 500.
- Pastel bg + saturated fg pair from the palette above.

### Avatar
- Circle, white text. Sizes: sm 22px (10px font), default 28px (12px), lg 36px (14px), xl 56px (20px).
- Avatar stack: items overlap by -6px with a 2px surface-color border.

### Project card
- Surface bg, 14px radius, 1px border, sm shadow.
- 56px colored banner with a 36×36 frosted-glass icon tile.
- Body: 14/18 padding with name, clamped 2-line description, footer (stats + member stack), 4px progress bar.

### Filter chip
- 6/12 padding, 999px radius, 12.5px / 500.
- Default: surface bg, strong border, text-2 color.
- Active: indigo fill, white text.
- "My tickets" variant: indigo-tint fill instead of full fill.

### Modal
- 20px radius, large shadow, slide-up entry.
- Head + body + foot rows; foot has surface-2 background to separate it visually.

### Side sheet
- 720px wide, slides in from right with a 0.25 alpha scrim under it.
- Two-column body (1fr / 240px), border-left between columns.

---

## State Management

Per-screen state (lift up only as needed):
- `view: 'login' | 'dashboard' | 'project'`
- `theme: 'light' | 'dark'` (persist to localStorage in production)
- `projectId: string | null`
- `openTicketId: string | null` (controls sheet visibility)
- `createProjectOpen: boolean`, `createTicketOpen: boolean`

Project view local state:
- `view: 'list' | 'board'`
- `search: string`
- `filters: { status, priority, assignee, tag, dateRange, mineOnly }`
- Computed `tickets` is a filtered + searched derivation of the source list.

Modals own their form state internally and call back on submit; the parent shows a transient toast.

## Data Model (suggested)

```ts
type Project = {
  id: string; key: string; name: string; description: string;
  icon: string; color: string;
  members: UserId[];
  openCount: number; totalCount: number; progress: number; // 0..1
};

type Ticket = {
  id: string; // e.g. "WEB-142"
  title: string; description: string;
  status: 'open' | 'progress' | 'done' | 'blocked';
  priority: 'low' | 'med' | 'high' | 'urgent';
  assigneeId: UserId; reporterId: UserId;
  tags: string[]; // 'bug' | 'feature' | 'design' | 'research' | 'docs' | 'chore'
  dueDate: string; // ISO
  comments: Comment[]; attachments: Attachment[]; watchers: UserId[];
};
```

---

## Assets

- All iconography is inline SVG from a small handcrafted set (`Icon` object in `data.jsx`). In production, swap for the codebase's icon library (Lucide, Phosphor, etc.) — these are stand-ins.
- Project icons are emoji placeholders. Replace with the codebase's icon picker if one exists, or commit to emoji as the system.
- No external imagery; replace mock blobs/avatars with real ones in production.
- Font: **Geist** (Vercel) via Google Fonts. If the codebase already mandates a different family, use that.

---

## Files in this bundle

- `Worknest.html` — the entry HTML, wires React + the design canvas + boots the app
- `styles.css` — all design tokens + component styles (light + dark)
- `data.jsx` — design data (projects, tickets, people), icon set, small badges
- `screens.jsx` — the screen components: `LoginScreen`, `Sidebar`, `Dashboard`, `ProjectView`, `TicketSheet`, `CreateProjectModal`, `CreateTicketModal`
- `design-canvas.jsx` — design canvas wrapper (presentation only — strip in production)

To run the prototype locally: serve the folder over any static server and open `Worknest.html`. Click any artboard's expand icon to drive the full app at full size.
