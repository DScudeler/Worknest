// Worknest data + icons + small components

const Icon = {
  Search: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>,
  Plus: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14"/></svg>,
  X: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>,
  Filter: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M7 12h10M11 18h2"/></svg>,
  List: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>,
  Board: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="6" height="18" rx="1.5"/><rect x="11" y="3" width="6" height="12" rx="1.5"/><rect x="19" y="3" width="2" height="8" rx="1"/></svg>,
  Home: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9.5 12 3l9 6.5V20a2 2 0 0 1-2 2h-4v-7h-6v7H5a2 2 0 0 1-2-2z"/></svg>,
  Inbox: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11Z"/></svg>,
  Star: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
  Settings: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.42.18.79.43 1.09.74A1.65 1.65 0 0 0 21 9.05V9a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
  Bell: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>,
  Sun: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>,
  Moon: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>,
  More: () => <svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="6" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="18" r="1.5"/></svg>,
  ArrowLeft: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>,
  ArrowRight: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>,
  Check: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>,
  Calendar: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
  User: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  Tag: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.59 13.41 13.42 20.58a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>,
  Comment: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
  Paperclip: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>,
  File: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
  Image: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>,
  Send: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>,
  Github: () => <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12a12 12 0 0 0 8.21 11.39c.6.11.82-.26.82-.58v-2.16c-3.34.72-4.04-1.42-4.04-1.42-.55-1.39-1.34-1.76-1.34-1.76-1.09-.74.08-.73.08-.73 1.21.09 1.85 1.24 1.85 1.24 1.07 1.83 2.81 1.3 3.5.99.11-.78.42-1.3.76-1.6-2.66-.3-5.47-1.33-5.47-5.93 0-1.31.47-2.38 1.24-3.22-.13-.3-.54-1.52.11-3.18 0 0 1.01-.32 3.3 1.23a11.5 11.5 0 0 1 6 0c2.29-1.55 3.3-1.23 3.3-1.23.66 1.66.25 2.88.13 3.18.77.84 1.23 1.91 1.23 3.22 0 4.61-2.81 5.62-5.49 5.92.43.37.81 1.1.81 2.22v3.29c0 .32.22.7.83.58A12 12 0 0 0 24 12c0-6.63-5.37-12-12-12z"/></svg>,
  Google: () => <svg viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23z"/><path fill="#FBBC05" d="M5.84 14.1A6.6 6.6 0 0 1 5.5 12c0-.73.13-1.44.34-2.1V7.07H2.18A11 11 0 0 0 1 12c0 1.78.43 3.46 1.18 4.94l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.07.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1A11 11 0 0 0 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"/></svg>,
  Bug: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="8" y="6" width="8" height="14" rx="4"/><path d="M19 7l-3 2M5 7l3 2M19 13h-3M5 13h3M19 19l-3-2M5 19l3-2M12 2v4"/></svg>,
};

const PEOPLE = [
  { id: 'me', name: 'You', initials: 'YO', color: '#5b5fc7' },
  { id: 'maya', name: 'Maya Chen', initials: 'MC', color: '#0ea5e9' },
  { id: 'jay', name: 'Jay Patel', initials: 'JP', color: '#10b981' },
  { id: 'sam', name: 'Sam Rivera', initials: 'SR', color: '#f59e0b' },
  { id: 'lea', name: 'Lea Nakamura', initials: 'LN', color: '#ec4899' },
  { id: 'theo', name: 'Theo Brun', initials: 'TB', color: '#8b5cf6' },
];

const PROJECTS = [
  {
    id: 'p1', key: 'WEB', name: 'Marketing Website',
    desc: 'Full redesign of the public marketing site, including new pricing & blog templates.',
    icon: '🌐', color: 'var(--proj-5)', open: 12, total: 38, progress: 0.62, members: ['me','maya','jay','sam'],
  },
  {
    id: 'p2', key: 'MOB', name: 'Mobile App v2',
    desc: 'iOS + Android revamp. Onboarding, notifications, offline mode.',
    icon: '📱', color: 'var(--proj-2)', open: 24, total: 71, progress: 0.41, members: ['maya','lea','theo'],
  },
  {
    id: 'p3', key: 'INF', name: 'Infrastructure',
    desc: 'Migrate to multi-region. Improve CI pipeline. Cost monitoring dashboards.',
    icon: '⚙️', color: 'var(--proj-3)', open: 6, total: 22, progress: 0.78, members: ['jay','theo','me'],
  },
  {
    id: 'p4', key: 'DSGN', name: 'Design System 2.0',
    desc: 'Tokens, components, docs site. Light & dark first-class.',
    icon: '🎨', color: 'var(--proj-4)', open: 9, total: 31, progress: 0.55, members: ['lea','sam','me'],
  },
  {
    id: 'p5', key: 'GROW', name: 'Growth Experiments',
    desc: 'Activation, onboarding, referral. Weekly cadence of A/B tests.',
    icon: '📈', color: 'var(--proj-1)', open: 4, total: 18, progress: 0.85, members: ['sam','maya'],
  },
  {
    id: 'p6', key: 'CUST', name: 'Customer Support',
    desc: 'Help center revamp + macros + canned responses workflow.',
    icon: '💬', color: 'var(--proj-6)', open: 15, total: 44, progress: 0.32, members: ['lea','theo','jay'],
  },
];

const TICKETS = [
  { id: 'WEB-142', title: 'New pricing page hero with animated comparison',
    status: 'progress', priority: 'high', assignee: 'maya', tags: ['design','feature'],
    due: 'May 8', desc: 'Redesign hero section to include the animated tier comparison. Pull copy from latest brand doc.',
    comments: 4, attachments: 2 },
  { id: 'WEB-141', title: 'Blog post template — long-form layout',
    status: 'open', priority: 'med', assignee: 'sam', tags: ['design'],
    due: 'May 12', desc: 'Long-form template with TOC, callouts, embedded video.', comments: 1, attachments: 0 },
  { id: 'WEB-140', title: 'Fix CLS on /features (LCP image)',
    status: 'progress', priority: 'urgent', assignee: 'jay', tags: ['bug'],
    due: 'May 5', desc: 'Layout shift caused by lazy-loaded LCP. Reserve dimensions.', comments: 8, attachments: 1 },
  { id: 'WEB-139', title: 'Customer testimonial carousel',
    status: 'open', priority: 'low', assignee: 'me', tags: ['feature'],
    due: 'May 20', desc: 'Auto-rotating carousel; pause on hover; 6 quotes for launch.', comments: 0, attachments: 0 },
  { id: 'WEB-138', title: 'Audit and remove unused web fonts',
    status: 'done', priority: 'low', assignee: 'theo', tags: ['chore'],
    due: 'Apr 28', desc: 'Drop two unused families. Re-measure perf.', comments: 2, attachments: 0 },
  { id: 'WEB-137', title: 'Newsletter signup integrates with CRM',
    status: 'open', priority: 'med', assignee: 'me', tags: ['feature'],
    due: 'May 15', desc: 'Connect form to HubSpot. Map utm source/medium.', comments: 3, attachments: 0 },
  { id: 'WEB-136', title: 'Dark mode treatment for code blocks',
    status: 'progress', priority: 'med', assignee: 'lea', tags: ['design','feature'],
    due: 'May 10', desc: 'Carbon-style theme with proper contrast.', comments: 2, attachments: 4 },
  { id: 'WEB-135', title: 'Broken link in footer (twitter → x)',
    status: 'done', priority: 'low', assignee: 'sam', tags: ['bug'],
    due: 'Apr 30', desc: 'Update social icons + URL.', comments: 1, attachments: 0 },
  { id: 'WEB-134', title: 'Cookie banner — GDPR copy review',
    status: 'open', priority: 'high', assignee: 'maya', tags: ['docs','chore'],
    due: 'May 7', desc: 'Legal review needed. Final copy due Wednesday.', comments: 5, attachments: 1 },
  { id: 'WEB-133', title: 'A/B test new CTA button color',
    status: 'progress', priority: 'med', assignee: 'sam', tags: ['research','feature'],
    due: 'May 14', desc: 'Indigo vs coral. 50/50 split. Conversion target 1.4%.', comments: 6, attachments: 0 },
  { id: 'WEB-132', title: 'Add OpenGraph images for blog posts',
    status: 'open', priority: 'low', assignee: 'lea', tags: ['design'],
    due: 'May 22', desc: 'Auto-generated OG cards with post title.', comments: 0, attachments: 0 },
  { id: 'WEB-131', title: 'Performance budget tracker in CI',
    status: 'done', priority: 'high', assignee: 'jay', tags: ['chore'],
    due: 'Apr 25', desc: 'Lighthouse CI gate at 90 perf, 95 a11y.', comments: 3, attachments: 0 },
];

function Avatar({ p, size = '' }) {
  const person = typeof p === 'string' ? PEOPLE.find(x => x.id === p) : p;
  if (!person) return null;
  return (
    <span className={`avatar av ${size}`} style={{ background: person.color }} title={person.name}>
      {person.initials}
    </span>
  );
}

function StatusPill({ status }) {
  const map = {
    open: { label: 'Open', cls: 'status-open' },
    progress: { label: 'In Progress', cls: 'status-progress' },
    done: { label: 'Done', cls: 'status-done' },
    blocked: { label: 'Blocked', cls: 'status-blocked' },
  };
  const s = map[status];
  return <span className={`pill ${s.cls}`}><span className="dot"></span>{s.label}</span>;
}

function PriorityBadge({ priority }) {
  const map = { low: 'Low', med: 'Medium', high: 'High', urgent: 'Urgent' };
  return (
    <span className={`pri ${priority}`}>
      <span className="pri-bars"><span></span><span></span><span></span></span>
      {map[priority]}
    </span>
  );
}

function Tag({ name }) {
  return <span className={`tag ${name}`}>{name}</span>;
}

Object.assign(window, {
  Icon, PEOPLE, PROJECTS, TICKETS, Avatar, StatusPill, PriorityBadge, Tag,
});
