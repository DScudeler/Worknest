// Worknest screens

const { useState, useEffect, useMemo, useRef } = React;

// ===================== LOGIN =====================
function LoginScreen({ onLogin, theme, onToggleTheme }) {
  const [email, setEmail] = useState('alex@acme.co');
  const [pw, setPw] = useState('••••••••');
  const [busy, setBusy] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setBusy(true);
    setTimeout(() => onLogin(), 700);
  };

  return (
    <div className="login-page" data-screen-label="Login">
      <div className="login-art">
        <div className="blob b1"></div>
        <div className="blob b2"></div>
        <div className="login-logo">
          <span className="logo-mark">W</span>
          <span>Worknest</span>
        </div>
        <div className="quote">
          <h2>Where work finds its rhythm.</h2>
          <p>Tickets, projects, and the people doing the work — all in one calm place.</p>
        </div>
        <div className="preview-tickets">
          <div className="preview-ticket">
            <span className="pt-id">WEB-142</span>
            <span className="pt-title">New pricing page hero</span>
            <StatusPill status="progress" />
          </div>
          <div className="preview-ticket" style={{ marginLeft: 30 }}>
            <span className="pt-id">MOB-073</span>
            <span className="pt-title">Onboarding screens</span>
            <StatusPill status="open" />
          </div>
          <div className="preview-ticket" style={{ marginLeft: 60 }}>
            <span className="pt-id">DSGN-12</span>
            <span className="pt-title">Token sync to Figma</span>
            <StatusPill status="done" />
          </div>
        </div>
      </div>
      <div className="login-form-wrap">
        <form className="login-form" onSubmit={handleSubmit}>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 20 }}>
            <button type="button" className="theme-toggle" onClick={onToggleTheme} aria-label="Toggle theme">
              {theme === 'dark' ? <Icon.Sun/> : <Icon.Moon/>}
            </button>
          </div>
          <h1>Welcome back</h1>
          <p className="sub">Sign in to your Worknest workspace.</p>
          <div className="field">
            <label className="field-label">Email</label>
            <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" />
          </div>
          <div className="field">
            <label className="field-label" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>Password</span>
              <a href="#" style={{ color: 'var(--accent-500)', fontWeight: 500, textDecoration: 'none', fontSize: 12 }}>Forgot?</a>
            </label>
            <input className="input" type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
          </div>
          <button className="btn primary" type="submit" disabled={busy}>
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
          <div className="divider">or continue with</div>
          <div className="sso-row">
            <button type="button" className="sso-btn" onClick={() => onLogin()}><Icon.Google/> Google</button>
            <button type="button" className="sso-btn" onClick={() => onLogin()}><Icon.Github/> GitHub</button>
          </div>
          <div className="alt">New here? <a href="#">Create an account</a></div>
        </form>
      </div>
    </div>
  );
}

// ===================== SIDEBAR =====================
function Sidebar({ current, onNavigate, theme, onToggleTheme }) {
  return (
    <aside className="sidebar">
      <div className="logo">
        <span className="logo-mark">W</span>
        <span>Worknest</span>
      </div>
      <button className={`nav-item ${current === 'dashboard' ? 'active' : ''}`} onClick={() => onNavigate({ view: 'dashboard' })}>
        <Icon.Home/> Dashboard
      </button>
      <button className="nav-item">
        <Icon.Inbox/> Inbox
        <span style={{ marginLeft: 'auto', background: 'var(--accent-500)', color: 'white', fontSize: 10, padding: '1px 6px', borderRadius: 999, fontWeight: 600 }}>3</span>
      </button>
      <button className="nav-item">
        <Icon.Star/> My tickets
      </button>

      <div className="nav-section">Projects</div>
      {PROJECTS.slice(0, 5).map(p => (
        <button
          key={p.id}
          className={`nav-item ${current === 'project' ? 'active' : ''}`}
          onClick={() => onNavigate({ view: 'project', projectId: p.id })}
        >
          <span className="proj-dot" style={{ background: p.color }}></span>
          {p.name}
        </button>
      ))}
      <button className="nav-item" style={{ color: 'var(--text-3)' }} onClick={() => onNavigate({ view: 'dashboard', createProject: true })}>
        <Icon.Plus/> New project
      </button>

      <div style={{ flex: 1 }}></div>
      <button className="nav-item" onClick={onToggleTheme}>
        {theme === 'dark' ? <Icon.Sun/> : <Icon.Moon/>}
        {theme === 'dark' ? 'Light mode' : 'Dark mode'}
      </button>
      <button className="nav-item"><Icon.Settings/> Settings</button>
      <div className="sidebar-foot">
        <Avatar p="me" />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600 }}>Alex Kim</div>
          <div style={{ fontSize: 11, color: 'var(--text-3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>alex@acme.co</div>
        </div>
      </div>
    </aside>
  );
}

// ===================== DASHBOARD =====================
function Dashboard({ onOpenProject, onCreateProject }) {
  const totalOpen = PROJECTS.reduce((a, p) => a + p.open, 0);
  const stats = [
    { label: 'Open tickets', value: totalOpen, delta: '−4 this week' },
    { label: 'Assigned to me', value: 7, delta: '+2 today', deltaClass: 'neg' },
    { label: 'Due this week', value: 5 },
    { label: 'Active projects', value: PROJECTS.length, delta: '+1' },
  ];

  return (
    <div className="content" data-screen-label="Dashboard">
      <div className="page-head">
        <div>
          <h1>Good afternoon, <span className="greet-accent">Alex</span></h1>
          <p className="sub">Tuesday, May 5 · You have 5 tickets due this week.</p>
        </div>
        <button className="btn primary" onClick={onCreateProject}>
          <Icon.Plus/> New project
        </button>
      </div>

      <div className="stat-row">
        {stats.map((s, i) => (
          <div key={i} className="stat-card">
            <div className="label">{s.label}</div>
            <div className="value">{s.value}</div>
            {s.delta && <div className={`delta ${s.deltaClass || ''}`}>{s.delta}</div>}
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 14 }}>
        <h2 style={{ fontSize: 18, fontWeight: 600, margin: 0, letterSpacing: '-0.01em' }}>Your projects</h2>
        <span style={{ fontSize: 12.5, color: 'var(--text-3)' }}>{PROJECTS.length} projects</span>
      </div>

      <div className="proj-grid">
        {PROJECTS.map(p => (
          <div key={p.id} className="proj-card" onClick={() => onOpenProject(p.id)}>
            <div className="pc-banner" style={{ background: p.color }}>
              <span className="pc-icon">{p.icon}</span>
            </div>
            <div className="pc-body">
              <div className="pc-name">{p.name}</div>
              <div className="pc-desc">{p.desc}</div>
              <div className="pc-foot">
                <div className="pc-stats">
                  <span><Icon.Inbox/> {p.open} open</span>
                  <span>·</span>
                  <span>{Math.round(p.progress * 100)}%</span>
                </div>
                <div className="avatar-stack">
                  {p.members.slice(0, 3).map(m => <Avatar key={m} p={m} size="sm" />)}
                  {p.members.length > 3 && (
                    <span className="avatar sm" style={{ background: 'var(--surface-3)', color: 'var(--text-2)' }}>+{p.members.length - 3}</span>
                  )}
                </div>
              </div>
              <div className="progress"><div style={{ width: (p.progress * 100) + '%' }}></div></div>
            </div>
          </div>
        ))}
        <div className="proj-card create" onClick={onCreateProject}>
          <div style={{ textAlign: 'center' }}>
            <div className="plus">+</div>
            New project
          </div>
        </div>
      </div>
    </div>
  );
}

// ===================== PROJECT VIEW =====================
function ProjectView({ projectId, onOpenTicket, onCreateTicket, onBack }) {
  const project = PROJECTS.find(p => p.id === projectId) || PROJECTS[0];

  const [view, setView] = useState('list'); // list | board
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState({ status: null, priority: null, assignee: null, tag: null, dateRange: null, mineOnly: false });

  const tickets = useMemo(() => {
    return TICKETS.filter(t => {
      if (search && !t.title.toLowerCase().includes(search.toLowerCase()) && !t.id.toLowerCase().includes(search.toLowerCase())) return false;
      if (filters.status && t.status !== filters.status) return false;
      if (filters.priority && t.priority !== filters.priority) return false;
      if (filters.assignee && t.assignee !== filters.assignee) return false;
      if (filters.tag && !t.tags.includes(filters.tag)) return false;
      if (filters.mineOnly && t.assignee !== 'me') return false;
      return true;
    });
  }, [search, filters]);

  const updateFilter = (k, v) => setFilters(f => ({ ...f, [k]: f[k] === v ? null : v }));
  const clearFilters = () => setFilters({ status: null, priority: null, assignee: null, tag: null, dateRange: null, mineOnly: false });
  const activeCount = Object.values(filters).filter(v => v && v !== false).length;

  return (
    <div className="content" style={{ paddingBottom: 30 }} data-screen-label={`Project · ${project.name}`}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, fontSize: 13, color: 'var(--text-2)' }}>
        <button className="btn ghost" style={{ padding: '4px 8px' }} onClick={onBack}>← Projects</button>
      </div>

      <div className="page-head">
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <div style={{ width: 48, height: 48, borderRadius: 12, background: project.color, display: 'grid', placeItems: 'center', fontSize: 24 }}>
            {project.icon}
          </div>
          <div>
            <h1 style={{ marginBottom: 2 }}>{project.name}</h1>
            <p className="sub">{project.desc}</p>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div className="avatar-stack">
            {project.members.map(m => <Avatar key={m} p={m} />)}
          </div>
          <button className="btn secondary"><Icon.User/> Invite</button>
          <button className="btn primary" onClick={onCreateTicket}>
            <Icon.Plus/> New ticket
          </button>
        </div>
      </div>

      <div className="filter-bar">
        <div className="input-icon search">
          <Icon.Search/>
          <input className="input" placeholder="Search tickets…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>

        <FilterChip label="Status" value={filters.status} options={[
          { value: 'open', label: 'Open' },
          { value: 'progress', label: 'In Progress' },
          { value: 'done', label: 'Done' },
        ]} onChange={(v) => updateFilter('status', v)} />

        <FilterChip label="Priority" value={filters.priority} options={[
          { value: 'urgent', label: 'Urgent' },
          { value: 'high', label: 'High' },
          { value: 'med', label: 'Medium' },
          { value: 'low', label: 'Low' },
        ]} onChange={(v) => updateFilter('priority', v)} />

        <FilterChip label="Assignee" value={filters.assignee} options={PEOPLE.map(p => ({ value: p.id, label: p.name }))}
          onChange={(v) => updateFilter('assignee', v)} />

        <FilterChip label="Label" value={filters.tag} options={[
          { value: 'bug', label: 'Bug' }, { value: 'feature', label: 'Feature' },
          { value: 'design', label: 'Design' }, { value: 'research', label: 'Research' },
          { value: 'docs', label: 'Docs' }, { value: 'chore', label: 'Chore' },
        ]} onChange={(v) => updateFilter('tag', v)} />

        <FilterChip label="Date" value={filters.dateRange} options={[
          { value: 'week', label: 'This week' }, { value: 'overdue', label: 'Overdue' }, { value: 'next', label: 'Next 30 days' },
        ]} onChange={(v) => updateFilter('dateRange', v)} />

        <button
          className={`chip toggle-mine ${filters.mineOnly ? 'active' : ''}`}
          onClick={() => setFilters(f => ({ ...f, mineOnly: !f.mineOnly }))}
        >
          <Icon.User/> My tickets
        </button>

        {activeCount > 0 && (
          <button className="btn ghost" style={{ fontSize: 12.5 }} onClick={clearFilters}>Clear</button>
        )}

        <span style={{ flex: 1 }}></span>

        <span style={{ fontSize: 12.5, color: 'var(--text-3)' }}>{tickets.length} of {TICKETS.length}</span>
        <div className="view-toggle">
          <button className={view === 'list' ? 'active' : ''} onClick={() => setView('list')}><Icon.List/> List</button>
          <button className={view === 'board' ? 'active' : ''} onClick={() => setView('board')}><Icon.Board/> Board</button>
        </div>
      </div>

      {view === 'list' ? (
        <TicketList tickets={tickets} onOpenTicket={onOpenTicket} />
      ) : (
        <KanbanBoard tickets={tickets} onOpenTicket={onOpenTicket} onCreateTicket={onCreateTicket} />
      )}
    </div>
  );
}

function FilterChip({ label, value, options, onChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef();
  useEffect(() => {
    const close = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);
  const selected = options.find(o => o.value === value);
  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button className={`chip ${value ? 'active' : ''}`} onClick={() => setOpen(!open)}>
        {label}{selected ? `: ${selected.label}` : ''}
        {value && <span className="x" onClick={(e) => { e.stopPropagation(); onChange(value); }}><Icon.X/></span>}
      </button>
      {open && (
        <div style={{
          position: 'absolute', top: '100%', left: 0, marginTop: 4, zIndex: 20,
          background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10,
          boxShadow: 'var(--shadow-lg)', padding: 4, minWidth: 180,
        }}>
          {options.map(opt => (
            <button key={opt.value} onClick={() => { onChange(opt.value); setOpen(false); }} style={{
              display: 'flex', alignItems: 'center', gap: 8, width: '100%', textAlign: 'left',
              padding: '7px 10px', borderRadius: 6, fontSize: 13,
              background: opt.value === value ? 'var(--surface-3)' : 'transparent',
              color: 'var(--text)',
            }}>
              {opt.value === value && <Icon.Check/>}
              <span style={{ marginLeft: opt.value === value ? 0 : 22 }}>{opt.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function TicketList({ tickets, onOpenTicket }) {
  if (tickets.length === 0) {
    return (
      <div className="ticket-list" style={{ padding: 60, textAlign: 'center', color: 'var(--text-3)' }}>
        <div style={{ fontSize: 14 }}>No tickets match your filters.</div>
      </div>
    );
  }
  return (
    <div className="ticket-list">
      <div className="tl-head">
        <div>ID</div><div>Title</div><div>Status</div><div>Priority</div><div>Assignee</div><div>Due</div><div></div>
      </div>
      {tickets.map(t => (
        <div key={t.id} className="tl-row" onClick={() => onOpenTicket(t.id)}>
          <div className="id">{t.id}</div>
          <div className="title">
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.title}</span>
            <span className="tags">{t.tags.map(tag => <Tag key={tag} name={tag} />)}</span>
          </div>
          <div><StatusPill status={t.status} /></div>
          <div><PriorityBadge priority={t.priority} /></div>
          <div><Avatar p={t.assignee} size="sm" /></div>
          <div className={`due ${t.due === 'May 5' ? 'overdue' : ''}`}>{t.due}</div>
          <div style={{ display: 'flex', gap: 8, color: 'var(--text-3)', fontSize: 12 }}>
            {t.comments > 0 && <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}><Icon.Comment/>{t.comments}</span>}
            {t.attachments > 0 && <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}><Icon.Paperclip/>{t.attachments}</span>}
          </div>
        </div>
      ))}
    </div>
  );
}

function KanbanBoard({ tickets, onOpenTicket, onCreateTicket }) {
  const columns = [
    { id: 'open', label: 'Open', color: '#94a3b8' },
    { id: 'progress', label: 'In Progress', color: '#f59e0b' },
    { id: 'done', label: 'Done', color: '#10b981' },
    { id: 'blocked', label: 'Blocked', color: '#ef4444' },
  ];
  return (
    <div className="board">
      {columns.map(col => {
        const items = tickets.filter(t => t.status === col.id);
        return (
          <div className="board-col" key={col.id}>
            <div className="board-col-head">
              <div className="name">
                <span className="dot" style={{ background: col.color }}></span>
                {col.label}
                <span className="count">{items.length}</span>
              </div>
              <button className="btn ghost icon" onClick={onCreateTicket} style={{ width: 24, height: 24 }}><Icon.Plus/></button>
            </div>
            {items.map(t => (
              <div key={t.id} className="board-card" onClick={() => onOpenTicket(t.id)}>
                <div className="bc-id">{t.id}</div>
                <div className="bc-title">{t.title}</div>
                <div className="bc-tags" style={{ marginBottom: 10 }}>
                  {t.tags.map(tg => <Tag key={tg} name={tg} />)}
                </div>
                <div className="bc-meta">
                  <PriorityBadge priority={t.priority} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    {t.comments > 0 && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, color: 'var(--text-3)', fontSize: 11.5 }}><Icon.Comment/>{t.comments}</span>}
                    <Avatar p={t.assignee} size="sm" />
                  </div>
                </div>
              </div>
            ))}
            <button className="add-card-btn" onClick={onCreateTicket}>
              <Icon.Plus/> Add ticket
            </button>
          </div>
        );
      })}
    </div>
  );
}

// ===================== TICKET DETAIL (side sheet) =====================
function TicketSheet({ ticketId, onClose }) {
  const t = TICKETS.find(x => x.id === ticketId);
  const [status, setStatus] = useState(t.status);
  const [comment, setComment] = useState('');

  if (!t) return null;
  const assignee = PEOPLE.find(p => p.id === t.assignee);

  return (
    <div className="sheet" data-screen-label={`Ticket · ${t.id}`}>
      <div className="sheet-head">
        <span className="id-pill">{t.id}</span>
        <StatusPill status={status} />
        <span style={{ color: 'var(--text-3)', fontSize: 12 }}>updated 2h ago</span>
        <div className="right">
          <button className="btn ghost icon" title="More"><Icon.More/></button>
          <button className="btn ghost icon" onClick={onClose} title="Close"><Icon.X/></button>
        </div>
      </div>
      <div className="sheet-body">
        <div className="sheet-main">
          <h1>{t.title}</h1>

          <div className="desc">
            <p>{t.desc}</p>
            <p><strong>Acceptance criteria</strong></p>
            <ul>
              <li>Hero animates the three tier columns sliding into place on scroll</li>
              <li>Comparison toggle (monthly / yearly) preserves position</li>
              <li>Performs within budget on slow 4G (LCP &lt; 2.5s)</li>
              <li>Passes axe automated a11y checks</li>
            </ul>
          </div>

          {t.attachments > 0 && (
            <div>
              <div className="section-h">Attachments · {t.attachments}</div>
              <div className="attach-row">
                <div className="attach">
                  <span className="ico"><Icon.Image/></span>
                  <div>
                    <div className="name">hero-comparison-mock.png</div>
                    <div className="size">2.4 MB</div>
                  </div>
                </div>
                <div className="attach">
                  <span className="ico"><Icon.File/></span>
                  <div>
                    <div className="name">pricing-copy-final.md</div>
                    <div className="size">12 KB</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="section-h">Activity · {t.comments} comments</div>

          <Comment author="maya" time="2h ago" text="Pulled latest copy from the brand doc — it's tighter than what's in this ticket. I'll paste it below for review."/>
          <Comment author="me" time="1h ago" text="Looks good. One thought: can we make the yearly pill always visible instead of only on hover? It's our default and we want eyes on it."/>
          <Comment author="jay" time="35m ago" text="LCP question — current hero image is 380KB. We can probably get this under 200 with AVIF + responsive sizes. Want me to take a swing?"/>
          <Comment author="maya" time="22m ago" text="Yes please. I'll have updated mocks by EOD."/>

          <div className="composer" style={{ marginTop: 18 }}>
            <Avatar p="me" />
            <div className="composer-input">
              <textarea placeholder="Add a comment…" value={comment} onChange={(e) => setComment(e.target.value)} />
              <div className="composer-actions">
                <div style={{ display: 'flex', gap: 4 }}>
                  <button className="btn ghost icon" title="Attach"><Icon.Paperclip/></button>
                  <button className="btn ghost icon" title="Image"><Icon.Image/></button>
                </div>
                <button className="btn primary" disabled={!comment.trim()}>
                  <Icon.Send/> Comment
                </button>
              </div>
            </div>
          </div>
        </div>
        <aside className="sheet-side">
          <div className="prop">
            <span className="key">Status</span>
            <span className="val">
              <select className="select" style={{ padding: '5px 8px', fontSize: 12 }} value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="open">Open</option>
                <option value="progress">In Progress</option>
                <option value="done">Done</option>
                <option value="blocked">Blocked</option>
              </select>
            </span>
          </div>
          <div className="prop">
            <span className="key">Priority</span>
            <span className="val"><PriorityBadge priority={t.priority} /></span>
          </div>
          <div className="prop">
            <span className="key">Assignee</span>
            <span className="val"><Avatar p={t.assignee} size="sm" /> <span style={{ fontSize: 12.5 }}>{assignee.name}</span></span>
          </div>
          <div className="prop">
            <span className="key">Reporter</span>
            <span className="val"><Avatar p="me" size="sm" /> <span style={{ fontSize: 12.5 }}>You</span></span>
          </div>
          <div className="prop">
            <span className="key">Due</span>
            <span className="val" style={{ fontSize: 12.5 }}>{t.due}, 2026</span>
          </div>
          <div className="prop">
            <span className="key">Labels</span>
            <span className="val">{t.tags.map(tg => <Tag key={tg} name={tg} />)}</span>
          </div>
          <div className="prop">
            <span className="key">Project</span>
            <span className="val" style={{ fontSize: 12.5 }}>
              <span className="proj-dot" style={{ background: 'var(--proj-5)' }}></span>
              Marketing Website
            </span>
          </div>

          <div style={{ borderTop: '1px solid var(--border)', margin: '20px 0' }}></div>

          <div className="section-h">Watchers · 4</div>
          <div className="avatar-stack">
            {['me','maya','jay','lea'].map(m => <Avatar key={m} p={m} size="sm" />)}
          </div>
        </aside>
      </div>
    </div>
  );
}

function Comment({ author, time, text }) {
  const p = PEOPLE.find(x => x.id === author);
  return (
    <div className="comment">
      <Avatar p={author} size="sm" />
      <div className="body">
        <div className="meta"><strong>{p.name}</strong> <span>· {time}</span></div>
        <div>{text}</div>
      </div>
    </div>
  );
}

// ===================== CREATE PROJECT MODAL =====================
function CreateProjectModal({ onClose, onCreate }) {
  const [name, setName] = useState('');
  const [key, setKey] = useState('');
  const [desc, setDesc] = useState('');
  const [color, setColor] = useState('var(--proj-2)');
  const [icon, setIcon] = useState('🚀');
  const [members, setMembers] = useState(['me']);
  const [step, setStep] = useState(1);

  const colors = ['var(--proj-1)','var(--proj-2)','var(--proj-3)','var(--proj-4)','var(--proj-5)','var(--proj-6)'];
  const icons = ['🚀','✨','🎯','💡','🌱','🔥','🎨','📦','🛠️','🧭','📚','🪐','🦄','🌊','🍀','⚡'];

  useEffect(() => {
    if (name && !key) {
      setKey(name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 4));
    }
  }, [name]);

  const handleSubmit = () => {
    onCreate({ name: name || 'Untitled project', key, desc, color, icon, members });
  };

  return (
    <div className="scrim" onClick={onClose} data-screen-label="Create project">
      <div className="modal" onClick={(e) => e.stopPropagation()} style={{ width: 600 }}>
        <div className="modal-head">
          <h2>{step === 1 ? 'Create a new project' : 'Add your team'}</h2>
          <button className="btn ghost icon" onClick={onClose}><Icon.X/></button>
        </div>
        <div className="modal-body">
          {step === 1 ? (
            <>
              <div className="row-2" style={{ marginBottom: 16 }}>
                <div>
                  <label className="field-label">Project name</label>
                  <input className="input" placeholder="e.g. Mobile App v2" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
                </div>
                <div>
                  <label className="field-label">Key</label>
                  <input className="input" placeholder="MOB" value={key} onChange={(e) => setKey(e.target.value.toUpperCase().slice(0, 5))} style={{ fontFamily: 'ui-monospace, Menlo, monospace' }} />
                </div>
              </div>

              <div style={{ marginBottom: 16 }}>
                <label className="field-label">Description</label>
                <textarea className="textarea" placeholder="What is this project about?" value={desc} onChange={(e) => setDesc(e.target.value)}></textarea>
              </div>

              <div style={{ marginBottom: 16 }}>
                <label className="field-label">Cover color</label>
                <div className="color-grid">
                  {colors.map(c => (
                    <div key={c} className={`color-swatch ${c === color ? 'active' : ''}`} style={{ background: c }} onClick={() => setColor(c)}></div>
                  ))}
                </div>
              </div>

              <div>
                <label className="field-label">Icon</label>
                <div className="icon-grid">
                  {icons.map(i => (
                    <div key={i} className={`icon-cell ${i === icon ? 'active' : ''}`} onClick={() => setIcon(i)}>{i}</div>
                  ))}
                </div>
              </div>

              {/* Live preview */}
              <div style={{ marginTop: 24 }}>
                <label className="field-label">Preview</label>
                <div className="proj-card" style={{ maxWidth: 280, cursor: 'default' }}>
                  <div className="pc-banner" style={{ background: color }}>
                    <span className="pc-icon">{icon}</span>
                  </div>
                  <div className="pc-body">
                    <div className="pc-name">{name || 'Untitled project'}</div>
                    <div className="pc-desc">{desc || 'Add a description to help your team understand what this is for.'}</div>
                    <div className="pc-foot">
                      <div className="pc-stats"><span>0 open · 0%</span></div>
                      <div className="avatar-stack">
                        <Avatar p="me" size="sm" />
                      </div>
                    </div>
                    <div className="progress"><div style={{ width: '0%' }}></div></div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <>
              <p style={{ color: 'var(--text-2)', fontSize: 13.5, margin: '0 0 18px 0' }}>
                Invite teammates to collaborate. You can always add more later.
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {PEOPLE.map(p => (
                  <label key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 8, borderRadius: 8, cursor: 'pointer', background: members.includes(p.id) ? 'var(--accent-50)' : 'transparent' }}>
                    <input
                      type="checkbox"
                      checked={members.includes(p.id)}
                      onChange={() => setMembers(m => m.includes(p.id) ? m.filter(x => x !== p.id) : [...m, p.id])}
                      style={{ accentColor: 'var(--accent-500)' }}
                    />
                    <Avatar p={p.id} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 500, fontSize: 13.5 }}>{p.name}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{p.id === 'me' ? 'Project lead (you)' : `${p.name.toLowerCase().replace(' ','.')}@acme.co`}</div>
                    </div>
                  </label>
                ))}
              </div>
            </>
          )}
        </div>
        <div className="modal-foot">
          <button className="btn ghost" onClick={onClose}>Cancel</button>
          {step === 1 ? (
            <button className="btn primary" onClick={() => setStep(2)} disabled={!name.trim()}>
              Continue <Icon.ArrowRight/>
            </button>
          ) : (
            <>
              <button className="btn secondary" onClick={() => setStep(1)}>Back</button>
              <button className="btn primary" onClick={handleSubmit}>
                <Icon.Check/> Create project
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ===================== CREATE TICKET MODAL =====================
function CreateTicketModal({ onClose, onCreate, projectName = 'Marketing Website' }) {
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [priority, setPriority] = useState('med');
  const [status, setStatus] = useState('open');
  const [assignee, setAssignee] = useState('me');
  const [tags, setTags] = useState([]);
  const [due, setDue] = useState('');

  const allTags = ['bug','feature','design','research','docs','chore'];
  const toggleTag = (t) => setTags(arr => arr.includes(t) ? arr.filter(x => x !== t) : [...arr, t]);

  return (
    <div className="scrim" onClick={onClose} data-screen-label="Create ticket">
      <div className="modal" onClick={(e) => e.stopPropagation()} style={{ width: 620 }}>
        <div className="modal-head">
          <div>
            <h2>New ticket</h2>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>in {projectName}</div>
          </div>
          <button className="btn ghost icon" onClick={onClose}><Icon.X/></button>
        </div>
        <div className="modal-body">
          <input
            className="input"
            placeholder="Ticket title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            autoFocus
            style={{ fontSize: 16, fontWeight: 500, padding: '12px 14px', marginBottom: 12 }}
          />
          <textarea
            className="textarea"
            placeholder="Add a description… markdown supported"
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            style={{ minHeight: 120, marginBottom: 16 }}
          />

          <div className="row-3" style={{ marginBottom: 16 }}>
            <div>
              <label className="field-label">Status</label>
              <select className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="open">Open</option>
                <option value="progress">In Progress</option>
                <option value="done">Done</option>
                <option value="blocked">Blocked</option>
              </select>
            </div>
            <div>
              <label className="field-label">Priority</label>
              <select className="select" value={priority} onChange={(e) => setPriority(e.target.value)}>
                <option value="low">Low</option>
                <option value="med">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
            <div>
              <label className="field-label">Assignee</label>
              <select className="select" value={assignee} onChange={(e) => setAssignee(e.target.value)}>
                {PEOPLE.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
          </div>

          <div style={{ marginBottom: 16 }}>
            <label className="field-label">Due date</label>
            <div className="input-icon" style={{ maxWidth: 200 }}>
              <Icon.Calendar/>
              <input className="input" type="date" value={due} onChange={(e) => setDue(e.target.value)} />
            </div>
          </div>

          <div>
            <label className="field-label">Labels</label>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {allTags.map(t => (
                <button
                  key={t}
                  className={`tag ${t}`}
                  onClick={() => toggleTag(t)}
                  style={{
                    cursor: 'pointer', padding: '4px 10px', fontSize: 12,
                    opacity: tags.includes(t) ? 1 : 0.4,
                    boxShadow: tags.includes(t) ? '0 0 0 1.5px currentColor' : 'none',
                  }}
                >{t}</button>
              ))}
            </div>
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn primary" disabled={!title.trim()} onClick={() => onCreate({ title, desc, priority, status, assignee, tags, due })}>
            <Icon.Check/> Create ticket
          </button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  LoginScreen, Sidebar, Dashboard, ProjectView, TicketSheet,
  CreateProjectModal, CreateTicketModal,
});
